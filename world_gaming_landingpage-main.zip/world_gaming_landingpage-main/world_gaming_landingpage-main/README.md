**OUTPUTS**

![Screenshot (177)](https://github.com/user-attachments/assets/d24022be-1eca-4f38-828f-7d0575f3c7a2)
![Screenshot (178)](https://github.com/user-attachments/assets/e02a3eba-107b-4eef-ae6d-0bdf95a951f4)
![Screenshot (179)](https://github.com/user-attachments/assets/a9b5ce92-6988-452c-8d40-10f78d41fdc6)
![Screenshot (180)](https://github.com/user-attachments/assets/ecb55376-4189-42ea-88dc-b383ed63deb2)
![Screenshot (181)](https://github.com/user-attachments/assets/17c81a7a-2784-4230-80e8-916cc0d0fddd)
![Screenshot (182)](https://github.com/user-attachments/assets/c21e715f-ce12-4c38-8851-648ab6369201)
![Screenshot (183)](https://github.com/user-attachments/assets/cdd2d72a-e5cb-4b05-8fbe-b00a73bf16d5)

![Screenshot (185)](https://github.com/user-attachments/assets/70385d5e-6761-47ea-82e0-c23e415682ce)
